<?php
session_start(); // Pastikan session dimulai
ob_start(); // Mulai output buffering

include 'db.php';

// ========== TAMBAH MENU BARU (ADMIN/CANTEEN OWNER) ==========
if (isset($_POST['add_menu'])) {
    // Cek role: Hanya admin atau canteen owner yang bisa add menu
    if (!isset($_SESSION['role']) || ($_SESSION['role'] !== 'admin' && $_SESSION['user_type'] !== 'canteen')) {
        echo "Error: Anda tidak memiliki izin untuk menambah menu."; // Debugging - hapus setelah tes
        ob_end_clean();
        header("Location: index.php"); // Redirect ke halaman utama jika tidak authorized
        exit;
    }
    
    $canteen_id = intval($_POST['canteen_id']);
    $name = $conn->real_escape_string($_POST['name']);
    $price = floatval($_POST['price']);
    $photo = null;

    if (!empty($_FILES['photo']['name'])) {
        $photo = basename($_FILES['photo']['name']);
        $target_file = "images/" . $photo;
        move_uploaded_file($_FILES['photo']['tmp_name'], $target_file);
    }

    $stmt = $conn->prepare("INSERT INTO menus (canteen_id, name, price, photo) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isds", $canteen_id, $name, $price, $photo);
    if ($stmt->execute()) {
        $stmt->close();
        ob_end_clean();
        header("Location: canteen.php?id=" . $canteen_id); // Redirect ke halaman canteen setelah add menu
        exit;
    } else {
        echo "Error: Gagal menambah menu. " . $stmt->error; // Debugging - hapus setelah tes
        $stmt->close();
    }
    
    // Jika gagal, tetap redirect
    ob_end_clean();
    header("Location: canteen.php?id=" . $canteen_id);
    exit;
}

// ========== HAPUS RATING (USER) ==========
if (isset($_POST['delete_rating'])) {
    $rating_id = intval($_POST['rating_id']);
    $canteen_id = intval($_POST['canteen_id']);
    
    // Cek apakah rating milik user yang login (untuk keamanan ekstra)
    $stmt_check = $conn->prepare("SELECT user_name FROM ratings WHERE id = ?");
    $stmt_check->bind_param("i", $rating_id);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();
    $stmt_check->close();
    
    if ($result_check->num_rows > 0) {
        $row = $result_check->fetch_assoc();
        if ($row['user_name'] === $_SESSION['username']) {
            // Hapus rating
            $stmt_delete = $conn->prepare("DELETE FROM ratings WHERE id = ?");
            $stmt_delete->bind_param("i", $rating_id);
            if ($stmt_delete->execute()) {
                $stmt_delete->close();
                ob_end_clean();
                header("Location: view_canteen.php?id=" . $canteen_id);
                exit;
            } else {
                echo "Error: Gagal menghapus rating. " . $stmt_delete->error; // Debugging - hapus setelah tes
                $stmt_delete->close();
            }
        } else {
            echo "Error: Anda tidak memiliki izin untuk menghapus rating ini."; // Debugging - hapus setelah tes
        }
    } else {
        echo "Error: Rating tidak ditemukan."; // Debugging - hapus setelah tes
    }
    
    // ========== HAPUS RATING (ADMIN) ==========
if (isset($_POST['delete_rating_admin'])) {
    // Admin bisa hapus semua komentar
    if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
        $rating_id = intval($_POST['rating_id']);
        $canteen_id = intval($_POST['canteen_id']);
        
        $stmt_delete = $conn->prepare("DELETE FROM ratings WHERE id = ?");
        $stmt_delete->bind_param("i", $rating_id);
        if ($stmt_delete->execute()) {
            $stmt_delete->close();
            ob_end_clean();
            header("Location: admin/dashboard.php");
            exit;
        } else {
            echo "Error: Gagal menghapus komentar. " . $stmt_delete->error;
            $stmt_delete->close();
        }
    } else {
        echo "Error: Anda tidak memiliki izin.";
    }
    
    ob_end_clean();
    header("Location: admin/dashboard.php");
    exit;
}
    // Jika gagal, tetap redirect
    ob_end_clean();
    header("Location: view_canteen.php?id=" . $canteen_id);
    exit;
}

// ========== SIMPAN RATING BARU ==========
if (isset($_POST['submit_rating'])) {
    $canteen_id = intval($_POST['canteen_id']);
    $user = $conn->real_escape_string($_POST['user_name']);
    $comment = $conn->real_escape_string($_POST['comment']);
    $rating = intval($_POST['rating']);
    $photo = null;

    if (!empty($_FILES['photo']['name'])) {
        $photo = basename($_FILES['photo']['name']);
        $target_file = "images/" . $photo;
        move_uploaded_file($_FILES['photo']['tmp_name'], $target_file);
    }

    $stmt = $conn->prepare("INSERT INTO ratings (canteen_id, user_name, comment, rating, photo) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("issis", $canteen_id, $user, $comment, $rating, $photo);
    $stmt->execute();
    $stmt->close();

    ob_end_clean(); // Bersihkan buffer sebelum redirect
    header("Location: view_canteen.php?id=" . $canteen_id);
    exit;
}

// ========== UPDATE KANTIN (ADMIN) ==========
// Catatan: admin_edit.php di root folder memanggil ini.
// Sebaiknya fungsi ini dipindahkan ke admin/edit_canteen.php jika admin_edit.php dihapus.
if (isset($_POST['update'])) {
    $id = intval($_POST['id']);
    $name = $conn->real_escape_string($_POST['name']);
    $current_photo = ''; // Ambil foto lama dari DB jika tidak ada upload baru

    // Ambil foto lama
    $res = $conn->query("SELECT photo FROM canteens WHERE id=$id");
    if ($res && $res->num_rows > 0) {
        $row = $res->fetch_assoc();
        $current_photo = $row['photo'];
    }

    $photo = $current_photo; // Default ke foto lama

    if (!empty($_FILES['photo']['name'])) {
        $photo = basename($_FILES['photo']['name']);
        $target_file = "images/" . $photo;
        move_uploaded_file($_FILES['photo']['tmp_name'], $target_file);
    }

    $stmt = $conn->prepare("UPDATE canteens SET name=?, photo=? WHERE id=?");
    $stmt->bind_param("ssi", $name, $photo, $id);
    $stmt->execute();
    $stmt->close();

    ob_end_clean(); // Bersihkan buffer sebelum redirect
    header("Location: index.php"); // Redirect ke halaman utama setelah update
    exit;
}

ob_end_flush(); // Flush buffer di akhir jika tidak ada redirect
?>