<?php
session_start();

// Cek login dan role admin
if (!isset($_SESSION['username']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

include '../db.php';

// Ambil semua kantin
$result = $conn->query("SELECT * FROM canteens ORDER BY id ASC");

// Ambil semua rating untuk hapus komentar
$ratings_result = $conn->query("SELECT r.*, c.name AS canteen_name FROM ratings r JOIN canteens c ON r.canteen_id = c.id ORDER BY r.id DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - Klik Kantin</title>
    <link rel="stylesheet" href="../style.css">
    <style>
        /* Penyesuaian proporsi untuk tampilan lebih enak */
        .canteens {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
            gap: 20px; /* Jarak antar item lebih besar */
            margin: 20px 0;
        }
        .canteen-item {
            background: white;
            border: 1px solid #ddd;
            border-radius: 8px;
            width: 280px; /* Lebar lebih proporsional */
            margin: 10px;
            padding: 20px; /* Padding lebih besar untuk ruang */
            text-align: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            transition: transform 0.2s; /* Efek hover */
        }
        .canteen-item:hover {
            transform: translateY(-5px); /* Sedikit naik saat hover */
        }
        .canteen-item img {
            width: 100%;
            height: 180px; /* Tinggi gambar lebih proporsional */
            object-fit: cover;
            border-radius: 5px;
            margin-bottom: 15px; /* Jarak bawah gambar */
        }
        .canteen-item h3 {
            color: #ff8c00;
            margin: 10px 0;
            font-size: 18px; /* Font lebih besar */
        }
        .btn {
            display: inline-block;
            background-color: #ff8c00;
            color: white;
            padding: 10px 15px;
            text-decoration: none;
            border-radius: 5px;
            margin: 5px;
            font-size: 14px; /* Font tombol proporsional */
            transition: background-color 0.3s;
        }
        .btn:hover {
            background-color: #e67e22;
        }
        .btn-success {
            background-color: #28a745;
        }
        .btn-success:hover {
            background-color: #218838;
        }
        .btn-secondary {
            background-color: #6c757d;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
        }
        .btn-danger {
            background-color: #dc3545;
        }
        .btn-danger:hover {
            background-color: #c82333;
        }
        .no-canteens {
            text-align: center;
            padding: 40px;
            background: white;
            border-radius: 8px;
            margin: 20px 0;
        }
        .container {
            max-width: 1200px; /* Lebar container lebih besar untuk proporsi */
            margin: 0 auto;
            padding: 20px;
        }
        /* Warna text navbar agar terlihat (putih untuk kontras di background orange) */
        .navbar h1 {
            color: white; /* Sesuaikan dengan tema, putih agar terlihat */
            font-size: 20px; /* Ukuran text lebih kecil agar tidak terlalu besar */
        }
        /* Posisi text "Daftar Kantin" ke tengah halaman */
        h2 {
            text-align: center;
            color: #ff8c00; /* Sesuaikan dengan tema */
        }
        /* Section komentar untuk admin */
        .comments-section {
            margin-top: 40px;
            padding: 20px;
            background: #f9f9f9;
            border-radius: 8px;
        }
        .comments-section h3 {
            text-align: center;
            color: #ff8c00;
        }
        .comment-item {
            background: white;
            padding: 15px;
            margin: 10px 0;
            border-radius: 5px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        @media (max-width: 768px) {
            .canteen-item {
                width: 100%; /* Full width di mobile */
                margin: 10px 0;
            }
            .canteens {
                gap: 10px;
            }
        }
    </style>
</head>
<body>
    <header class="navbar">
        <h1>🍱 Klik Kantin - Dashboard Admin</h1> <!-- Ukuran font lebih kecil -->
        <div class="nav-right">
            <span>Halo, <?php echo htmlspecialchars($_SESSION['username']); ?> 👋</span>
            <a href="../logout.php" class="btn-logout">Logout</a>
        </div>
    </header>

    <div class="container">
        <h2>Daftar Kantin</h2>
        <a href="add_canteen.php" class="btn">Tambah Kantin Baru</a>
        <br><br>

        <?php if ($result && $result->num_rows > 0): ?>
            <div class="canteens">
                <?php while ($row = $result->fetch_assoc()): ?>
                    <div class="canteen-item">
                        <?php 
                        $image = !empty($row['photo']) ? '../images/' . $row['photo'] : 'https://via.placeholder.com/300x150/ff8c00/ffffff?text=No+Image';
                        ?>
                        <img src="<?php echo $image; ?>" alt="<?php echo htmlspecialchars($row['name']); ?>" onerror="this.src='https://via.placeholder.com/300x150/ff8c00/ffffff?text=No+Image';">
                        <h3><?php echo htmlspecialchars($row['name']); ?></h3>
                        <!-- Tambahkan "Lihat Menu" -->
                        <a href="../view_canteen.php?id=<?php echo $row['id']; ?>" class="btn">Lihat Menu</a>
                        <a href="edit_canteen.php?id=<?php echo $row['id']; ?>" class="btn btn-success">Edit Kantin</a>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <div class="no-canteens">
                <h3>Belum Ada Kantin</h3>
                <p>Belum ada kantin yang terdaftar. Silakan tambahkan kantin baru.</p>
                <a href="add_canteen.php" class="btn">Tambah Kantin</a>
            </div>
        <?php endif; ?>

        <!-- Section komentar untuk admin hapus -->
        <div class="comments-section">
            <h3>Kelola Komentar</h3>
            <?php if ($ratings_result && $ratings_result->num_rows > 0): ?>
                <?php while ($r = $ratings_result->fetch_assoc()): ?>
                    <div class="comment-item">
                        <strong><?php echo htmlspecialchars($r['user_name']); ?> - <?php echo htmlspecialchars($r['canteen_name']); ?></strong>
                        <p><?php echo htmlspecialchars($r['comment']); ?> (⭐ <?php echo $r['rating']; ?>/5)</p>
                        <form action="../upload.php" method="POST" style="display: inline;">
                            <input type="hidden" name="rating_id" value="<?php echo $r['id']; ?>">
                            <input type="hidden" name="canteen_id" value="<?php echo $r['canteen_id']; ?>">
                            <button type="submit" name="delete_rating_admin" class="btn btn-danger" onclick="return confirm('Hapus komentar ini?')">Hapus Komentar</button>
                        </form>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>Belum ada komentar.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>