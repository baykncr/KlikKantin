<?php
session_start();

// Cek login dan role admin
if (!isset($_SESSION['username']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

include '../db.php';

$id = intval($_GET['id']);
$canteen = $conn->query("SELECT * FROM canteens WHERE id=$id")->fetch_assoc();

if (!$canteen) {
    echo "Kantin tidak ditemukan.";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $conn->real_escape_string($_POST['name']);
    $contact = $conn->real_escape_string($_POST['contact']);
    $wa_link = $conn->real_escape_string($_POST['wa_link']);
    $photo = $canteen['photo'];

    if (!empty($_FILES['photo']['name'])) {
        $photo = basename($_FILES['photo']['name']);
        $target_file = "../images/" . $photo;
        move_uploaded_file($_FILES['photo']['tmp_name'], $target_file);
    }

    $stmt = $conn->prepare("UPDATE canteens SET name=?, contact=?, wa_link=?, photo=? WHERE id=?");
    $stmt->bind_param("ssssi", $name, $contact, $wa_link, $photo, $id);
    if ($stmt->execute()) {
        $stmt->close();
        header("Location: dashboard.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Kantin - Klik Kantin</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <header class="navbar">
        <h1>🍱 Klik Kantin - Admin</h1>
        <div class="nav-right">
            <span>Halo, <?php echo htmlspecialchars($_SESSION['username']); ?> 👋</span>
            <a href="../logout.php" class="btn-logout">Logout</a>
        </div>
    </header>

    <div class="container">
        <h2>Edit Kantin: <?php echo htmlspecialchars($canteen['name']); ?></h2>
        <form action="" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="name">Nama Kantin</label>
                <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($canteen['name']); ?>" required>
            </div>
            <!-- Tambahkan kolom kontak -->
            <div class="form-group">
                <label for="contact">Kontak</label>
                <input type="text" id="contact" name="contact" value="<?php echo htmlspecialchars($canteen['contact'] ?? ''); ?>" placeholder="Masukkan kontak">
            </div>
            <!-- Tambahkan kolom link WA -->
            <div class="form-group">
                <label for="wa_link">Link WhatsApp</label>
                <input type="url" id="wa_link" name="wa_link" value="<?php echo htmlspecialchars($canteen['wa_link'] ?? ''); ?>" placeholder="https://wa.me/...">
            </div>
            <div class="form-group">
                <label for="photo">Foto Kantin (Opsional)</label>
                <input type="file" id="photo" name="photo" accept="image/*">
            </div>
            <button type="submit" class="btn">Simpan Perubahan</button>
        </form>
        <br><a href="dashboard.php" class="btn btn-secondary">← Kembali ke Dashboard</a>
    </div>
</body>
</html>