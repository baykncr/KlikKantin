<?php
session_start();

// Cek login dan role (hanya admin atau canteen owner)
if (!isset($_SESSION['username']) || (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') && (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'canteen')) {
    header("Location: ../login.php");
    exit();
}

include '../db.php';

// Perbaikan: Jika canteen_id atau id tidak ada, redirect ke dashboard (bukan tampilkan error)
$canteen_id = isset($_GET['canteen_id']) ? intval($_GET['canteen_id']) : (isset($_GET['id']) ? intval($_GET['id']) : 0);
if ($canteen_id <= 0) {
    header("Location: dashboard.php"); // Redirect otomatis ke dashboard
    exit();
}

// Ambil data kantin untuk konfirmasi
$canteen = $conn->query("SELECT * FROM canteens WHERE id=$canteen_id")->fetch_assoc();
if (!$canteen) {
    header("Location: dashboard.php"); // Redirect jika kantin tidak ditemukan
    exit();
}

// Handle form submit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $conn->real_escape_string(trim($_POST['name']));
    $price = floatval($_POST['price']);
    $photo = null;

    // Validasi input
    if (empty($name) || $price <= 0) {
        $error = "Nama menu dan harga harus diisi dengan benar.";
    } else {
        // Upload foto jika ada
        if (!empty($_FILES['photo']['name'])) {
            $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
            $max_size = 2 * 1024 * 1024; // 2MB
            $file_type = $_FILES['photo']['type'];
            $file_size = $_FILES['photo']['size'];

            if (!in_array($file_type, $allowed_types)) {
                $error = "Tipe file foto tidak didukung. Hanya JPG, PNG, atau GIF.";
            } elseif ($file_size > $max_size) {
                $error = "Ukuran file foto terlalu besar. Maksimal 2MB.";
            } else {
                $photo = basename($_FILES['photo']['name']);
                $target_file = "../images/" . $photo;
                if (!move_uploaded_file($_FILES['photo']['tmp_name'], $target_file)) {
                    $error = "Gagal mengupload foto.";
                }
            }
        }

        if (!isset($error)) {
            // Gunakan 'isds' untuk 4 parameter (int, string, double, string)
            $stmt = $conn->prepare("INSERT INTO menus (canteen_id, name, price, photo) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("isds", $canteen_id, $name, $price, $photo);
            if ($stmt->execute()) {
                $stmt->close();
                // Redirect ke edit_menu.php untuk admin
                header("Location: edit_menu.php?canteen_id=" . $canteen_id . "&success=menu_added");
                exit();
            } else {
                $error = "Error: Gagal menambah menu. " . $stmt->error;
                $stmt->close();
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Menu - <?php echo htmlspecialchars($canteen['name']); ?></title>
    <link rel="stylesheet" href="../style.css">
    <style>
        /* Tambahan CSS untuk proporsi yang lebih baik */
        .form-container {
            max-width: 600px;
            margin: 2rem auto;
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            padding: 2rem;
        }
        .form-group {
            margin-bottom: 1.5rem;
        }
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: bold;
            color: #333;
        }
        .form-group input, .form-group input[type="file"] {
            width: 100%;
            padding: 0.75rem;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 1rem;
            transition: border-color 0.3s;
        }
        .form-group input:focus {
            border-color: #ff8c00;
            outline: none;
        }
        .btn {
            padding: 0.75rem;
            border: none;
            border-radius: 8px;
            font-size: 1.1rem;
            cursor: pointer;
            transition: background 0.3s;
        }
        .btn-save {
            width: 100%;
            background: #28a745; /* Hijau untuk simpan */
            color: white;
        }
        .btn-save:hover {
            background: #218838;
        }
        .btn-back {
            width: auto; /* Kecil, tidak full-width */
            padding: 0.5rem 1rem;
            font-size: 0.9rem;
            background: #6c757d; /* Abu-abu untuk kembali */
            color: white;
            text-decoration: none;
            display: inline-block;
        }
        .btn-back:hover {
            background: #5a6268;
        }
        .alert {
            padding: 1rem;
            border-radius: 5px;
            margin-bottom: 1rem;
        }
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        @media (max-width: 768px) {
            .form-container {
                padding: 1rem;
                margin: 1rem;
            }
        }
    </style>
</head>
<body>
    <header class="navbar">
        <h1>🍱 Klik Kantin - Admin</h1>
        <div class="nav-right">
            <span>Halo, <?php echo htmlspecialchars($_SESSION['username']); ?> 👋</span>
            <a href="../logout.php" class="btn-logout">Logout</a>
        </div>
    </header>

    <div class="container">
        <div class="form-container">
            <h2 style="text-align: center; color: #ff8c00; margin-bottom: 1.5rem;">Tambah Menu untuk <?php echo htmlspecialchars($canteen['name']); ?></h2>
            
            <?php if (isset($error)): ?>
                <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            
            <form action="" method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="name">Nama Menu</label>
                    <input type="text" id="name" name="name" required value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>">
                </div>
                <div class="form-group">
                    <label for="price">Harga (Rp)</label>
                    <input type="number" id="price" name="price" step="0.01" min="0" required value="<?php echo isset($_POST['price']) ? htmlspecialchars($_POST['price']) : ''; ?>">
                </div>
                <div class="form-group">
                    <label for="photo">Foto Menu (Opsional)</label>
                    <input type="file" id="photo" name="photo" accept="image/*">
                    <small style="color: #666;">Maksimal 2MB, format: JPG, PNG, GIF.</small>
                </div>
                <button type="submit" class="btn btn-save">Simpan Menu</button>
            </form>
            <br>
            <a href="edit_menu.php?canteen_id=<?php echo $canteen_id; ?>" class="btn-back">← Kembali ke Edit Menu</a>
        </div>
    </div>
</body>
</html>