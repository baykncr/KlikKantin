<?php
session_start();

// Cek login (semua user yang login bisa akses, termasuk mahasiswa)
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

include 'db.php';

$canteen_id = intval($_GET['id']);
$canteen = $conn->query("SELECT * FROM canteens WHERE id=$canteen_id")->fetch_assoc();

if (!$canteen) {
    echo "Kantin tidak ditemukan.";
    exit();
}

// Ambil menu kantin menggunakan prepared statement
$stmt_menus = $conn->prepare("SELECT * FROM menus WHERE canteen_id = ? ORDER BY name ASC");
$stmt_menus->bind_param("i", $canteen_id);
$stmt_menus->execute();
$menus = $stmt_menus->get_result();
$stmt_menus->close();

// Ambil rating kantin menggunakan prepared statement
$stmt_ratings = $conn->prepare("SELECT * FROM ratings WHERE canteen_id = ? ORDER BY id DESC");
$stmt_ratings->bind_param("i", $canteen_id);
$stmt_ratings->execute();
$ratings = $stmt_ratings->get_result();
$stmt_ratings->close();
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo htmlspecialchars($canteen['name']); ?> - Klik Kantin</title>
  <link rel="stylesheet" href="style.css">
  <style>
    /* Tambahan CSS untuk responsivitas dan tampilan */
    .img-thumbnail {
      max-width: 100%;
      height: auto;
      border-radius: 8px;
      margin-top: 10px;
    }
    .menu-grid, .rating-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
      gap: 15px;
      margin: 20px 0;
    }
    .card {
      background: white;
      border: 1px solid #ddd;
      border-radius: 8px;
      padding: 15px;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
      text-align: center;
    }
    .rating-badge {
      background: #ff8c00;
      color: white;
      padding: 5px 10px;
      border-radius: 5px;
      font-weight: bold;
    }
    .form-group {
      margin-bottom: 15px;
    }
    .form-group label {
      display: block;
      margin-bottom: 5px;
      font-weight: bold;
    }
    .form-group input, .form-group textarea {
      width: 100%;
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 5px;
      box-sizing: border-box;
    }
    .btn {
      background-color: #ff8c00;
      color: white;
      padding: 10px 15px;
      text-decoration: none;
      border-radius: 5px;
      border: none;
      cursor: pointer;
      transition: background-color 0.3s;
    }
    .btn:hover {
      background-color: #e67e22;
    }
    .btn-danger {
      background-color: #dc3545;
    }
    .btn-danger:hover {
      background-color: #c82333;
    }
    .btn-secondary {
      background-color: #6c757d;
    }
    .btn-secondary:hover {
      background-color: #5a6268;
    }
    /* Perubahan: Warna text "Klik Kantin" agar kontras (putih) */
    .navbar h1 {
      color: white; /* Kontras di background orange */
    }
    /* Perubahan: Border pada informasi kontak agar lebih rapi */
    .contact-section {
      background: #f9f9f9;
      padding: 20px;
      border-radius: 8px;
      margin: 20px 0;
      text-align: center;
      border: 1px solid #ddd; /* Tambahkan border */
    }
    .contact-section h3 {
      color: #ff8c00;
    }
    .contact-section a {
      color: #ff8c00;
      text-decoration: none;
    }
    .contact-section a:hover {
      text-decoration: underline;
    }
    /* Perubahan: Text judul kantin dan menu tersedia ke tengah */
    h2, h3 {
      text-align: center;
    }
    /* Perubahan: Gambar kantin ke tengah dan perbesar sedikit */
    .canteen-image {
      display: block;
      margin: 0 auto;
      height: 200px; /* Perbesar dari 150px */
      margin-bottom: 30px; /* Tambahkan jarak bawah agar tidak berdempetan dengan text "Menu Tersedia" */
    }
    @media (max-width: 768px) {
      .menu-grid, .rating-grid {
        grid-template-columns: 1fr; /* Satu kolom di mobile */
      }
      .card {
        padding: 10px;
      }
      .container {
        padding: 10px;
      }
    }
  </style>
</head>
<body>
  <header class="navbar">
    <h1>🍱 Klik Kantin</h1> <!-- Sekarang putih agar kontras -->
    <div class="nav-right">
      <span>Halo, <?php echo htmlspecialchars($_SESSION['username']); ?> 👋</span>
      <a href="logout.php" class="btn-logout">Logout</a>
    </div>
  </header>

  <div class="container">
    <h2><?php echo htmlspecialchars($canteen['name']); ?></h2> <!-- Sekarang di tengah -->
    <?php if (!empty($canteen['photo'])): ?>
      <img src="images/<?php echo htmlspecialchars($canteen['photo']); ?>" alt="Foto Kantin" class="img-thumbnail canteen-image"> <!-- Sekarang di tengah, lebih besar, dan ada jarak -->
    <?php endif; ?>

    <h3>Menu Tersedia</h3> <!-- Sekarang di tengah -->
    <div class="menu-grid">
      <?php if ($menus->num_rows > 0): ?>
        <?php while ($m = $menus->fetch_assoc()): ?>
          <div class="card">
            <h4><?php echo htmlspecialchars($m['name']); ?></h4>
            <p>Harga: Rp<?php echo number_format($m['price'], 0, ',', '.'); ?></p>
            <?php if (!empty($m['photo'])): ?>
              <img src="images/<?php echo htmlspecialchars($m['photo']); ?>" alt="Foto Menu" class="img-thumbnail">
            <?php endif; ?>
          </div>
        <?php endwhile; ?>
      <?php else: ?>
        <p>Belum ada menu untuk kantin ini.</p>
      <?php endif; ?>
    </div>

    <!-- Perubahan: Tambahkan section informasi kontak dan link WA -->
    <div class="contact-section">
      <h3>Informasi Kontak</h3>
      <?php if (!empty($canteen['contact'])): ?>
        <p><strong>Kontak:</strong> <?php echo htmlspecialchars($canteen['contact']); ?></p>
      <?php endif; ?>
      <?php if (!empty($canteen['wa_link'])): ?>
        <p><a href="<?php echo htmlspecialchars($canteen['wa_link']); ?>" target="_blank">Hubungi via WhatsApp</a></p>
      <?php endif; ?>
      <?php if (empty($canteen['contact']) && empty($canteen['wa_link'])): ?>
        <p>Informasi kontak belum tersedia.</p>
      <?php endif; ?>
    </div>

    <h3>Rating dan Komentar</h3>
    <div class="rating-grid">
      <?php if ($ratings->num_rows > 0): ?>
        <?php while ($r = $ratings->fetch_assoc()): ?>
          <div class="card">
            <strong><?php echo htmlspecialchars($r['user_name']); ?></strong>
            <p><?php echo htmlspecialchars($r['comment']); ?></p>
            <span class="rating-badge">⭐ <?php echo $r['rating']; ?>/5</span>
            <?php if (!empty($r['photo'])): ?>
              <img src="images/<?php echo htmlspecialchars($r['photo']); ?>" alt="Foto Rating" class="img-thumbnail">
            <?php endif; ?>
            <!-- Tombol Hapus: Hanya tampil jika user_name cocok dengan session username -->
            <?php if (isset($_SESSION['username']) && $_SESSION['username'] === $r['user_name']): ?>
              <form action="upload.php" method="POST" style="margin-top: 10px;">
                <input type="hidden" name="rating_id" value="<?php echo $r['id']; ?>">
                <input type="hidden" name="canteen_id" value="<?php echo $canteen_id; ?>">
                <button type="submit" name="delete_rating" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus rating ini?')">Hapus Rating</button>
              </form>
            <?php endif; ?>
          </div>
        <?php endwhile; ?>
      <?php else: ?>
        <p>Belum ada rating untuk kantin ini.</p>
      <?php endif; ?>
    </div>

    <!-- Form untuk submit rating baru -->
    <h3>Beri Rating</h3>
    <form action="upload.php" method="POST" enctype="multipart/form-data">
      <input type="hidden" name="canteen_id" value="<?php echo $canteen_id; ?>">
      <div class="form-group">
        <label for="user_name">Nama Anda</label>
        <input type="text" id="user_name" name="user_name" placeholder="Masukkan nama Anda" required>
      </div>
      <div class="form-group">
        <label for="comment">Komentar</label>
        <textarea id="comment" name="comment" placeholder="Tulis komentar Anda" required></textarea>
      </div>
      <div class="form-group">
        <label for="rating">Rating (1-5)</label>
        <input type="number" id="rating" name="rating" min="1" max="5" placeholder="1-5" required>
      </div>
      <div class="form-group">
        <label for="photo">Foto (Opsional)</label>
        <input type="file" id="photo" name="photo" accept="image/*">
      </div>
      <button type="submit" name="submit_rating" class="btn btn-primary">Kirim Rating</button>
    </form>

    <!-- Perubahan: Ubah tulisan tombol dan direct berdasarkan role -->
    <?php
    $back_link = (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') ? 'admin/dashboard.php' : 'index.php';
    ?>
    <br><a href="<?php echo $back_link; ?>" class="btn btn-secondary">Kembali ke Daftar Kantin</a>
  </div>
</body>
</html>