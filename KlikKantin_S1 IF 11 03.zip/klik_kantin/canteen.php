<?php
session_start();

// Cek login sebagai canteen owner
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'canteen') {
    header('Location: login.php');
    exit();
}

// Data menu sementara (array untuk demo, ganti dengan DB nanti)
if (!isset($_SESSION['menus'])) {
    $_SESSION['menus'] = [
        [
            'id' => 1,
            'nama' => 'Nasi Goreng',
            'deskripsi' => 'Nasi goreng spesial dengan telur',
            'harga' => 15000,
            'gambar' => '' // Kosong untuk demo
        ],
        [
            'id' => 2,
            'nama' => 'Mie Ayam',
            'deskripsi' => 'Mie ayam halal',
            'harga' => 12000,
            'gambar' => '' // Kosong untuk demo
        ]
    ];
}

$menus = &$_SESSION['menus']; // Referensi untuk modifikasi
$alert = '';

// Proses Tambah Menu
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $nama = trim($_POST['nama']);
    $deskripsi = trim($_POST['deskripsi']);
    $harga = (int)$_POST['harga'];
    $gambar = '';

    if (!empty($nama) && $harga > 0) {
        // Upload gambar jika ada
        if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = 'uploads/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }
            $file_extension = strtolower(pathinfo($_FILES['gambar']['name'], PATHINFO_EXTENSION));
            if (in_array($file_extension, ['jpg', 'jpeg', 'png', 'gif'])) {
                $gambar = 'menu_' . time() . '.' . $file_extension;
                if (move_uploaded_file($_FILES['gambar']['tmp_name'], $upload_dir . $gambar)) {
                    // Sukses upload
                } else {
                    $alert = '<div class="alert alert-error">Gagal upload gambar!</div>';
                }
            } else {
                $alert = '<div class="alert alert-error">Format gambar tidak didukung!</div>';
            }
        }

        // Tambah ke array
        $new_id = empty($menus) ? 1 : max(array_column($menus, 'id')) + 1;
        $menus[] = [
            'id' => $new_id,
            'nama' => $nama,
            'deskripsi' => $deskripsi,
            'harga' => $harga,
            'gambar' => $gambar
        ];
        $alert = '<div class="alert alert-success">Menu berhasil ditambahkan!</div>';
    } else {
        $alert = '<div class="alert alert-error">Data tidak lengkap!</div>';
    }
}

// Proses Delete Menu
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    foreach ($menus as $key => $menu) {
        if ($menu['id'] === $id) {
            // Hapus file gambar jika ada
            if (!empty($menu['gambar']) && file_exists('uploads/' . $menu['gambar'])) {
                unlink('uploads/' . $menu['gambar']);
            }
            unset($menus[$key]);
            $alert = '<div class="alert alert-success">Menu berhasil dihapus!</div>';
            break;
        }
    }
    // Re-index array
    $menus = array_values($menus);
}

// Proses Update Menu (POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'edit') {
    $id = (int)$_POST['id'];
    $nama = trim($_POST['nama']);
    $deskripsi = trim($_POST['deskripsi']);
    $harga = (int)$_POST['harga'];
    $old_gambar = $_POST['old_gambar'] ?? '';

    if (!empty($nama) && $harga > 0) {
        // Upload gambar baru jika ada
        $gambar = $old_gambar;
        if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] === UPLOAD_ERR_OK) {
            // Hapus gambar lama jika ada
            if (!empty($old_gambar) && file_exists('uploads/' . $old_gambar)) {
                unlink('uploads/' . $old_gambar);
            }
            $upload_dir = 'uploads/';
            $file_extension = strtolower(pathinfo($_FILES['gambar']['name'], PATHINFO_EXTENSION));
            if (in_array($file_extension, ['jpg', 'jpeg', 'png', 'gif'])) {
                $gambar = 'menu_' . time() . '.' . $file_extension;
                move_uploaded_file($_FILES['gambar']['tmp_name'], $upload_dir . $gambar);
            }
        }

        // Update di array
        foreach ($menus as &$menu) {
            if ($menu['id'] === $id) {
                $menu['nama'] = $nama;
                $menu['deskripsi'] = $deskripsi;
                $menu['harga'] = $harga;
                $menu['gambar'] = $gambar;
                break;
            }
        }
        $alert = '<div class="alert alert-success">Menu berhasil diupdate!</div>';
    } else {
        $alert = '<div class="alert alert-error">Data tidak lengkap!</div>';
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Canteen - Klik Kantin</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f9fa;
            color: #333;
        }

        /* Header */
        .header {
            background-color: #ff8c00;
            color: white;
            padding: 15px 0;
            margin-bottom: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            width: 100%;
        }
        .nav-container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
        }
        .header h1 {
            margin: 0;
            font-size: 24px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .header h1::before {
            content: "🍱";
            font-size: 28px;
        }
        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
            margin: 0;
            font-size: 16px;
            font-weight: bold;
        }
        .logout {
            background-color: #fff;
            color: #ff8c00;
            padding: 8px 16px;
            border-radius: 20px;
            text-decoration: none;
            font-weight: bold;
            transition: background-color 0.3s;
        }
        .logout:hover {
            background-color: #f0f0f0;
        }

        /* Konten Utama */
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        .page-title {
            text-align: center;
            margin-bottom: 30px;
            color: #ff8c00;
            font-size: 28px;
            font-weight: bold;
        }
        .actions {
            display: flex;
            justify-content: center;
            margin-bottom: 30px;
            gap: 15px;
        }
        .btn {
            background-color: #ff8c00;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 25px;
            text-decoration: none;
            font-size: 16px;
            font-weight: bold;
            transition: background-color 0.3s, transform 0.2s;
            cursor: pointer;
            display: inline-block;
            box-sizing: border-box;
        }
        .btn:hover {
            background-color: #e67e00;
            transform: translateY(-2px);
        }
        .btn-secondary {
            background-color: #6c757d;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
        }
        .btn-edit {
            background-color: #007bff;
        }
        .btn-edit:hover {
            background-color: #0056b3;
        }
        .btn-delete {
            background-color: #dc3545;
        }
        .btn-delete:hover {
            background-color: #c82333;
        }

        /* Form Section */
        .form-section {
            background: white;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }
        .form-group input, .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            box-sizing: border-box;
        }
        .form-group input:focus, .form-group textarea:focus {
            border-color: #ff8c00;
            outline: none;
        }

        /* Daftar Menu */
        .menu-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        .menu-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            transition: box-shadow 0.3s, transform 0.2s;
        }
        .menu-card:hover {
            box-shadow: 0 6px 12px rgba(0,0,0,0.15);
            transform: translateY(-5px);
        }
        .menu-card h3 {
            color: #ff8c00;
            margin: 0 0 10px;
            font-size: 20px;
        }
        .menu-card p {
            margin: 5px 0;
            color: #666;
        }
        .menu-card .price {
            font-size: 18px;
            font-weight: bold;
            color: #28a745;
            margin: 10px 0;
        }
        .menu-card img {
            width: 100%;
            height: 150px;
            object-fit: cover;
            border-radius: 5px;
            margin-top: 10px;
        }
        .menu-actions {
            display: flex;
            gap: 10px;
            margin-top: 15px;
        }
        .menu-actions .btn {
            padding: 8px 12px;
            font-size: 14px;
            flex: 1;
            text-align: center;
        }

        /* Alert */
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
            font-weight: bold;
        }
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        /* Responsif */
        @media (max-width: 768px) {
            .nav-container {
                flex-direction: column;
                gap: 10px;
                text-align: center;
                padding: 0 15px;
            }
            .user-info {
                justify-content: center;
                gap: 10px;
            }
            .actions {
                flex-direction: column;
                align-items: center;
            }
            .menu-grid {
                grid-template-columns: 1fr;
                gap: 15px;
            }
            .container {
                padding: 10px;
            }
            .page-title {
                font-size: 24px;
            }
            .menu-actions {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>

    <!-- Header -->
    <div class="header">
        <div class="nav-container">
            <h1>Klik Kantin</h1>
            <div class="user-info">
                Halo, <?php echo htmlspecialchars($_SESSION['username'] ?? 'User '); ?>! (Canteen)
                <a href="logout.php" class="logout">Logout</a>
            </div>
        </div>
    </div>

    <!-- Konten Utama -->
    <div class="container">
        <?php if (!empty($alert)): ?>
            <?php echo $alert; ?>
        <?php endif; ?>

        <h2 class="page-title">Dashboard Canteen Anda</h2>

        <!-- Tombol Aksi -->
        <div class="actions">
            <a href="#" onclick="toggleForm()" class="btn">Tambah Menu Baru</a>
            <a href="orders.php" class="btn btn-secondary">Lihat Pesanan</a>
        </div>

        <!-- Form Tambah/Edit Menu -->
        <div id="add-menu" class="form-section" style="display: none;">
            <h3 id="form-title">Tambah Menu Baru</h3>
            <form method="POST" enctype="multipart/form-data" id="menu-form">
                <input type="hidden" name="action" value="add" id="form-action">
                <input type="hidden" name="id" id="form-id">
                <input type="hidden" name="old_gambar" id="form-old-gambar">
                <div class="form-group">
                    <label for="nama">Nama Menu:</label>
                    <input type="text" id="nama" name="nama" required>
                </div>
                <div class="form-group">
                    <label for="deskripsi">Deskripsi:</label>
                    <textarea id="deskripsi" name="deskripsi" rows="3"></textarea>
                </div>
                <div class="form-group">
                    <label for="harga">Harga (Rp):</label>
                    <input type="number" id="harga" name="harga" required min="1">
                </div>
                <div class="form-group">
                    <label for="gambar">Gambar Menu:</label>
                    <input type="file" id="gambar" name="gambar" accept="image/*">
                    <div id="current-image"></div>
                </div>
                <button type="submit" class="btn">Simpan Menu</button>
                <a href="#" onclick="cancelEdit()" class="btn btn-secondary" id="cancel-btn" style="display: none;">Batal</a>
            </form>
        </div>

        <!-- Daftar Menu -->
        <h3>Daftar Menu Anda</h3>
        <?php if (empty($menus)): ?>
            <p style="text-align: center; color: #666; padding: 20px;">Belum ada menu. Tambahkan menu pertama Anda!</p>
        <?php else: ?>
            <div class="menu-grid">
                <?php foreach ($menus as $menu): ?>
                    <div class="menu-card">
                        <h3><?php echo htmlspecialchars($menu['nama']); ?></h3>
                        <p><?php echo htmlspecialchars($menu['deskripsi']); ?></p>
                        <div class="price">Rp <?php echo number_format($menu['harga'], 0, ',', '.'); ?></div>
                        <?php if (!empty($menu['gambar']) && file_exists('uploads/' . $menu['gambar'])): ?>
                            <img src="uploads/<?php echo htmlspecialchars($menu['gambar']); ?>" alt="<?php echo htmlspecialchars($menu['nama']); ?>">
                        <?php else: ?>
                            <div